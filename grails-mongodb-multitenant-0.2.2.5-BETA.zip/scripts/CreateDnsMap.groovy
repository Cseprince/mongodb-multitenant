includeTargets << grailsScript("Init")

target(main: "This will create the default domain classes that maps tenants towards servernames") {
  def ant = new AntBuilder();


  ant.mkdir(dir: 'grails-app/domain/se/webinventions')
  new File("grails-app/domain/se/webinventions/TenantDomainMap.groovy").write('''

package se.webinventions

import se.webinventions.mongomultitenant.TenantDomainMapProvider
import org.bson.types.ObjectId
/**
 * Class to map tenant to a specific url.
 */
class TenantDomainMap implements TenantDomainMapProvider{

ObjectId id


  Tenant tenant
  String domainUrl


         public Tenant getTenant() {
          return this.tenant;
          }
    public void setTenant(Tenant ten) {
        this.tenant=ten;
    }
    static constraints = {
    }
}

''')


   ant.mkdir(dir: 'grails-app/domain/se/webinventions')
  new File("grails-app/domain/se/webinventions/Tenant.groovy").write('''

package se.webinventions

import se.webinventions.mongomultitenant.TenantProvider
import org.bson.types.ObjectId

class Tenant implements TenantProvider {

    ObjectId id
    String collectionNameSuffix
    String databaseNameSuffix
    String name = ""
    static constraints = {
    }

  static mapping = {
     name index: true

   }

}

''')


}

setDefaultTarget(main)

