@artifact.package@import spock.lang.*
import grails.plugin.spock.*

class @artifact.name@ extends @artifact.superclass@ {
    def "feature method"() {

    }
}